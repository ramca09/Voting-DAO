const MAX_TIME_PRESSED = 500;

export default MAX_TIME_PRESSED;
