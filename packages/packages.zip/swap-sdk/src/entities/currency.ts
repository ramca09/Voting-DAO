import { NativeCurrency } from './nativeCurrency'
import { Token } from './token'

export type Currency = NativeCurrency | Token
